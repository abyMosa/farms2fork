<?php

include_once FRAPPE_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once FRAPPE_CORE_CPT_PATH . '/testimonials/helper-functions.php';