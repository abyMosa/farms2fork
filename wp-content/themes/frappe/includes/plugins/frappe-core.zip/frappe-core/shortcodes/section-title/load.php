<?php

include_once FRAPPE_CORE_SHORTCODES_PATH . '/section-title/functions.php';
include_once FRAPPE_CORE_SHORTCODES_PATH . '/section-title/section-title.php';