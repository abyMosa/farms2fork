<div class="eltdf-uncovering-sections">
	<ul class="eltdf-us-wrapper curtains" data-image-holder-name=".eltdf-uss-image-holder" data-fade-element-name=".eltdf-fss-shadow">
		<?php echo do_shortcode($content); ?>
	</ul>
    <div class="eltdf-fss-shadow"></div>
</div>