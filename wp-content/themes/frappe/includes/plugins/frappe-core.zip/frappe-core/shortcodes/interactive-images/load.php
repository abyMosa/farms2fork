<?php
include_once FRAPPE_CORE_SHORTCODES_PATH . '/interactive-images/functions.php';
include_once FRAPPE_CORE_SHORTCODES_PATH . '/interactive-images/interactive-images.php';