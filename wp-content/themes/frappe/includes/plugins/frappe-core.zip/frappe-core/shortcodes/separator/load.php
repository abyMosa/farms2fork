<?php

include_once FRAPPE_CORE_SHORTCODES_PATH . '/separator/functions.php';
include_once FRAPPE_CORE_SHORTCODES_PATH . '/separator/separator.php';