<div class="eltdf-full-screen-image-slider <?php echo esc_attr($holder_classes); ?>">
	<div class="eltdf-fsis-slider eltdf-owl-slider" <?php echo frappe_elated_get_inline_attrs($slider_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
	<div class="eltdf-fsis-thumb-nav eltdf-fsis-prev-nav"></div>
	<div class="eltdf-fsis-thumb-nav eltdf-fsis-next-nav"></div>
	<div class="eltdf-fsis-slider-mask"></div>
</div>