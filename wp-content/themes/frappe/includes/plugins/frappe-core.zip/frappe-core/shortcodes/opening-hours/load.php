<?php

include_once FRAPPE_CORE_SHORTCODES_PATH . '/opening-hours/functions.php';
include_once FRAPPE_CORE_SHORTCODES_PATH . '/opening-hours/opening-hours.php';