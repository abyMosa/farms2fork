<?php

include_once FRAPPE_CORE_SHORTCODES_PATH . '/full-screen-image-slider/functions.php';
include_once FRAPPE_CORE_SHORTCODES_PATH . '/full-screen-image-slider/full-screen-image-slider.php';
include_once FRAPPE_CORE_SHORTCODES_PATH . '/full-screen-image-slider/full-screen-image-slider-item.php';