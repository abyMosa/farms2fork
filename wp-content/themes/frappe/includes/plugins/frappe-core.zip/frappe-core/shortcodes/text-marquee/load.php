<?php

include_once FRAPPE_CORE_SHORTCODES_PATH . '/text-marquee/functions.php';
include_once FRAPPE_CORE_SHORTCODES_PATH . '/text-marquee/text-marquee.php';