<?php

include_once FRAPPE_CORE_SHORTCODES_PATH . '/icon/functions.php';
include_once FRAPPE_CORE_SHORTCODES_PATH . '/icon/icon.php';